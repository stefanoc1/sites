<?php

namespace Stripe;

/**
 * Class Card
 *
 * @package Stripe
 */
class Card extends ExternalAccount
{

}
